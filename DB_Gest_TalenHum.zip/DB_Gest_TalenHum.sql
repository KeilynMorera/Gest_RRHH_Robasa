create database DB_Gest_TalenHum

use DB_Gest_TalenHum

----------------------------Orde de las tablas

--------------Tablas para el registro de Empresas, Gerencia, Departamento y Puestos
--Tabla: Empresa
/*Catalógalo de empresas que forman parte del grupo Robasa*/
CREATE TABLE Empresas (
    idEmpresa INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(150) NOT NULL,
	Descripcion VARCHAR(1000) NOT NULL
);

select * from Empresas

--Tabla: Gerencia
/*Gerencia dentro de cada empresa*/
CREATE TABLE Gerencia (
    idGerencia INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(150) NOT NULL,
	idEmpresa INT NOT NULL,
    CONSTRAINT FK_Empresa FOREIGN KEY (idEmpresa) REFERENCES Empresas(idEmpresa)
);

select * from Gerencia

--Tabla: Departamento
/*Departamentos que agrupan puestos dentro de cada gerencia*/
CREATE TABLE Departamento (
    id_Depertamento INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(150) NOT NULL,
	idGerencia INT NOT NULL,
    CONSTRAINT FK_Gerencia FOREIGN KEY (idGerencia) REFERENCES Gerencia(idGerencia)
);

Select * from Departamento

--Tabla: Puesto
/*Catálogo de puestos disponibles en la organización*/
CREATE TABLE Puesto (
    idPuesto INT IDENTITY(1,1) PRIMARY KEY,
    Nombre VARCHAR(150) NOT NULL,
	Descripcion VARCHAR(400) NOT NULL,
	id_Depertamento INT NOT NULL,
    CONSTRAINT FK_Departamento FOREIGN KEY (id_Depertamento) REFERENCES Departamento(id_Depertamento)
);

select * from Puesto


--Tabla: Compensacion_Puesto
/*Define la compensación base asignada a cada puesto.
Se usa como referencia para reclutamiento y para el historial
de salarial inicial del colaborador*/
CREATE TABLE Compensacion_Puesto (
    idCompensacion INT IDENTITY(1,1) PRIMARY KEY,
    Salario_Bruto DECIMAL(12,2) NOT NULL,
    Salario_Sem_Neto DECIMAL(12,2) NOT NULL,
    Comision_Base DECIMAL(12,2) NOT NULL DEFAULT 0,
    Variable_Base DECIMAL(12,2) NOT NULL DEFAULT 0,
    Viaticos_Alimenticios DECIMAL(12,2) NOT NULL DEFAULT 0,
    Kilometraje_Base DECIMAL(12,2) NOT NULL DEFAULT 0,
    Bono_Base DECIMAL(12,2) NOT NULL DEFAULT 0,
    Vigencia DATE NOT NULL,
    idPuesto INT NOT NULL,
    CONSTRAINT FK_Compensacion_Puesto
        FOREIGN KEY (idPuesto)
        REFERENCES Puesto(idPuesto),
    CONSTRAINT UQ_Puesto_Vigencia
        UNIQUE (idPuesto, Vigencia)
);

select * from Compensacion_Puesto



--------------Tablas para el registro de Personas, Empleados y Pasantes

--Tabla: PersonaSexo
CREATE TABLE PersonaSexo (
    idSexo INT IDENTITY(1,1) PRIMARY KEY,
	Sexo VARCHAR(20) NOT NULL
);
--Tabla: PersonaSexo
-- Insertar las opciones estándar para la tabla de Sexo
INSERT INTO PersonaSexo (Sexo) VALUES ('Masculino');
INSERT INTO PersonaSexo (Sexo) VALUES ('Femenino');
INSERT INTO PersonaSexo (Sexo) VALUES ('No Especificado');

-- Verificar que los datos se cargaron correctamente
SELECT * FROM PersonaSexo;

--Tabla: Persona
/*Tabla central de datos personales*/
CREATE TABLE Persona (
    idPersona INT IDENTITY(1,1) PRIMARY KEY,
    Nombre_Completo VARCHAR(200) NOT NULL,
	Cedula VARCHAR(20) NOT NULL,
	Fecha_Nacimiento date NOT NULL,
	Telefono VARCHAR(20) NULL,
	Celular VARCHAR(20) NOT NULL,
	Correo VARCHAR(200) NOT NULL,
	Direccion VARCHAR(400) NOT NULL,
	Foto VARCHAR(255) NULL, --se guardara la dirección de la carpeta donde se guardara la foto
	idSexo INT NOT NULL,
	CONSTRAINT FK_PersonaSexo FOREIGN KEY (idSexo) REFERENCES PersonaSexo(idSexo)
);

select * from Persona

DELETE FROM Persona
WHERE idPersona IN (6);


--Tabla: Contrato
/*Tipo de contrato*/
CREATE TABLE Contrato (
    idContrato INT IDENTITY(1,1) PRIMARY KEY,
	Tipo_Contrato VARCHAR(50) NOT NULL
);
-- Inserción de datos en la tabla Contrato
INSERT INTO Contrato (Tipo_Contrato) VALUES 
('Indefinido'),
('Término Fijo'),
('Obra o Labor'),
('Por Horas'),
('Práctica / Pasantía'),
('Prestación de Servicios'),
('Temporal / Eventual'),
('Confianza y Manejo');

SELECT * FROM Contrato

--Tabla: Empleado
/*Colaboradores directos de la empresa. Referencia a Persona para datos personales*/
CREATE TABLE Empleado (
    idEmpleado INT IDENTITY(1,1) PRIMARY KEY,
    Fecha_Ingreso date NOT NULL,
	Activo BIT NOT NULL DEFAULT 1, --Estado 1.Activo  0.Inactivo
	idContrato INT NOT NULL,
	CONSTRAINT FK_Contrato FOREIGN KEY (idContrato) REFERENCES Contrato(idContrato),
	idPersona INT NOT NULL,
    CONSTRAINT FK_Persona FOREIGN KEY (idPersona) REFERENCES Persona(idPersona),
	idPuesto INT NOT NULL,
    CONSTRAINT FK_Puesto_Empleado FOREIGN KEY (idPuesto) REFERENCES Puesto(idPuesto)
);

select * from Empleado

--Tabla: Pasante
/*Practicantes universitarios o estudiantes en prácticas universitarias*/
CREATE TABLE Pasante (
    idPasante INT IDENTITY(1,1) PRIMARY KEY,
    Fecha_Inicio date NOT NULL,
	Fecha_Fin date NULL,
	Univercidad VARCHAR(200) NOT NULL,
	Carrera VARCHAR(200) NOT NULL,
	Tutor_Univercitario VARCHAR(200) NOT NULL,
	Activo BIT NOT NULL DEFAULT 1, --Estado 1.Activo  0.Inactivo
	idPersona INT NOT NULL,
    CONSTRAINT FK_Persona_Pasante FOREIGN KEY (idPersona) REFERENCES Persona(idPersona),
	idPuesto INT NOT NULL,
    CONSTRAINT FK_Puesto_Pasante FOREIGN KEY (idPuesto) REFERENCES Puesto(idPuesto),
	idEmpleado_Sup INT NOT NULL,
    CONSTRAINT FK_Empleado_Supervisor FOREIGN KEY (idEmpleado_Sup) REFERENCES Empleado(idEmpleado)
);

select * from Pasante



--------------Tablas para el registro de Salarios

--Tabla: Salario_Empleado
/*Historial de periodos salariales por empleado. Cada vez que
cambia la compensación se crea un nuevo registro y se
cierra el anterior con fecha fin*/
CREATE TABLE Salario_Empleado (
    idSalarioEmpleado INT IDENTITY(1,1) PRIMARY KEY,
    Fecha_Inicio DATE NOT NULL,
    Fecha_Fin DATE NULL,
    Salario_Bruto DECIMAL(12,2) NOT NULL,
    Salario_Sem_Neto DECIMAL(12,2) NOT NULL,
    Comision_Base DECIMAL(12,2) NOT NULL DEFAULT 0,
    Variable_Base DECIMAL(12,2) NOT NULL DEFAULT 0,
    Viaticos_Alimenticios DECIMAL(12,2) NOT NULL DEFAULT 0,
    Kilometraje_Base DECIMAL(12,2) NOT NULL DEFAULT 0,
    Bono_Base DECIMAL(12,2) NOT NULL DEFAULT 0,
    Compensacion_Total DECIMAL(12,2) NOT NULL, --Total de la suma de todos los componentes anteriores
    Observaciones VARCHAR(5000) NULL,
	idEmpleado INT NOT NULL,
    FOREIGN KEY (idEmpleado)
        REFERENCES Empleado(idEmpleado)
);

select * from Salario_Empleado



 ---------------------------Tablas de la parte de Reclutamiento

--Tabla: Estatus
/*Registro estatus de la vacante o de actividad*/
CREATE TABLE Estatus  (
    id_Estatus_Vacante INT IDENTITY(1,1) PRIMARY KEY,
    TipoEstatus VARCHAR(20) NOT NULL --(estado: abierta, en proceso, aprovada, cerrada, cancelada)
);
-- Inserción del "estatus" para la vacante
INSERT INTO Estatus (TipoEstatus) VALUES 
('Abierta'),
('En proceso'),
('Cerrada'),
('Aprobada'),
('Cancelada');

SELECT * FROM Estatus

--Tabla: Vacante
/*Registro de cada proceso de reclutamiento abierto en la empresa
Se puede obtrener el nombre de la vacante por medio del Puesto,
ya que viene siendo lo mismo con la diferencia que usualmente para publicarlo
se suele utilizar un nombre más atractivo.*/
CREATE TABLE Vacante  (
    id_Vacante INT IDENTITY(1,1) PRIMARY KEY,
    Fecha_Registro date NOT NULL,
	TituloPublicacion VARCHAR(150) NOT NULL, --Nombre con la que la vacante se presentara/publicara
	Motivo VARCHAR(200) NOT NULL,
	Expe_Requerida VARCHAR(500) NOT NULL,
	Salario_Bruto DECIMAL(12,2) NOT NULL,
	Compensacion_Total DECIMAL(12,2) NOT NULL, --Total de la suma de todos los componentes anteriores
	Cierre_Proceso date NULL
);

select * from Vacante


--Tabla: Vacante_Asig
/*Union de todo lo que ocupa llamar con FK el apartado de Vacante,
entre estos:
-la relación con la tabla del estado de la vacante,
-la relación con lo esencial de la vacante (la información)
-la relación con la tabla empelados para seleccionar todos aquellos responsables
*/
CREATE TABLE Vacante_Asig  (
    id_Vacante_Asig INT IDENTITY(1,1) PRIMARY KEY,
	id_Estatus_Vacante int NOT NULL,
    CONSTRAINT FK_Estatus_Vacante FOREIGN KEY (id_Estatus_Vacante) REFERENCES Estatus(id_Estatus_Vacante), --Tipos de estados que puede tener la vacante
	id_Vacante int NOT NULL,
	CONSTRAINT FK_Vacante FOREIGN KEY (id_Vacante) REFERENCES Vacante(id_Vacante), --Vacante a la que se asigna
	idEmpleado_Aut int NOT NULL,
    CONSTRAINT FK_Empleado_Aut FOREIGN KEY (idEmpleado_Aut) REFERENCES Empleado(idEmpleado), --Empleado que autorizo abrir la vacante
	idEmpleado_Rel_Ev int NOT NULL,
    CONSTRAINT FK_Empleado_Rel_Ev FOREIGN KEY (idEmpleado_Rel_Ev) REFERENCES Empleado(idEmpleado), --Empleado que realiza la evaluación asignada
	idEmpleado_Sus int NULL,
    CONSTRAINT FK_Empleado_Sus FOREIGN KEY (idEmpleado_Sus) REFERENCES Empleado(idEmpleado), --Empleado al que se sustituye, solo si aplica
	idEmpleado_Jef_Puest int NOT NULL,
    CONSTRAINT FK_Empleado_Jef_Puest FOREIGN KEY (idEmpleado_Jef_Puest) REFERENCES Empleado(idEmpleado), --Empleado que es el jefe directo del puesto que se va cubrir
	idPuesto int NOT NULL,
    CONSTRAINT FK_Puesto FOREIGN KEY (idPuesto) REFERENCES Puesto(idPuesto) --Se selecciona el puesto y muestra su compensación total y el salario bruto
);

select * from Vacante_Asig


--Tabla: FaseCandidato
/*Registro las fases por las que pasa cada candidato que participo en la vacante*/
CREATE TABLE FaseCandidato  (
    id_Fase INT IDENTITY(1,1) PRIMARY KEY,
    Fase_Actual VARCHAR(25) NOT NULL
);
-- Inserción de fases típicas en un proceso de selección
INSERT INTO FaseCandidato (Fase_Actual) VALUES 
('Fase 1. Preselección'),
('Fase 2. Entrevista'),
('Fase 3. Evaluación Final'),
('Contratado'),
('Rechazado');

SELECT * FROM FaseCandidato

--Tabla: ProcesoFase
/*Registro estatus de la vacante o de actividad*/
CREATE TABLE ProcesoFase  (
    id_Proceso INT IDENTITY(1,1) PRIMARY KEY,
    Resultado_Av VARCHAR(80) NOT NULL
);
INSERT INTO ProcesoFase (Resultado_Av) VALUES 
('Avanzó (Paso a la siguiente fase)'),
('Descartado (No cumple perfil / Banco de talento)'),
('Seleccionado (Apto para contratación)');

SELECT * FROM ProcesoFase


--Tabla: Vacante_Candidato
/*Registro de cada candidato, que participo en un proceso de reclutamiento,
con la fase que alcanzo*/
CREATE TABLE Vacante_Candidato  (
    id_Candidato INT IDENTITY(1,1) PRIMARY KEY,
	Activo BIT NOT NULL DEFAULT 1, --Estado 1.Activo  0.Inactivo
	Observaciones VARCHAR(400) NOT NULL,
	id_Vacante int NOT NULL,
    CONSTRAINT FK_Vacante_sel FOREIGN KEY (id_Vacante) REFERENCES Vacante(id_Vacante), --Vacante en la que participo
	idPersona int NOT NULL,
    CONSTRAINT FK_Persona_Cand FOREIGN KEY (idPersona) REFERENCES Persona(idPersona), --Persona enlazada a la canditatura de vacante. NO IMPORTA si es interno o externo
	id_Fase int NOT NULL,
    CONSTRAINT FK_FaseCandidato FOREIGN KEY (id_Fase) REFERENCES FaseCandidato(id_Fase), --Fase de la que se encuentra el postulante
	id_Proceso int NOT NULL,
    CONSTRAINT FK_ProcesoFase FOREIGN KEY (id_Proceso) REFERENCES ProcesoFase(id_Proceso) --Fase de la que se encuentra el postulante
);

select * from Vacante_Candidato



 ---------------------------Tablas de la parte de Vacaciones
 
 --Tabla: Vacacion_Solicitud
/*Registro de cada solicitud vacaciones hecha por un empleado*/
CREATE TABLE Vacacion_Solicitud (
    idSolicitud INT IDENTITY(1,1) PRIMARY KEY,
    Fecha_Solicitud date NOT NULL,
	Fecha_Inicio date NOT NULL,
	Fecha_Fin date NOT NULL,
	Dias_Solicitud decimal(6,2) NOT NULL,
	id_Estatus_Vacante INT NOT NULL,
    CONSTRAINT FK_Estatus_Solicitud FOREIGN KEY (id_Estatus_Vacante) REFERENCES Estatus(id_Estatus_Vacante), --Estatus en la que se encuentra la salicitud
	idEmpleado_Sol_Vac INT NOT NULL,
    CONSTRAINT FK_Empleado_Sol_Vac FOREIGN KEY (idEmpleado_Sol_Vac) REFERENCES Empleado(idEmpleado), --Empleado que solicita las vacaciones
	idEmpleado_Respon INT NOT NULL,
    CONSTRAINT FK_Empleado_Respon FOREIGN KEY (idEmpleado_Respon) REFERENCES Empleado(idEmpleado) --Empleado que aprueba o rechaza la oferta
);

select * from Vacacion_Solicitud

delete from Vacacion_Solicitud
where idSolicitud = 5


--Tabla: Vacacion_Saldo
/*Registro de saldo anual de vacaciones por empleado. Se calcula automáticamente según su antigüedad*/
CREATE TABLE Vacacion_Saldo (
    idSaldo INT IDENTITY(1,1) PRIMARY KEY,
    Anio int NOT NULL,
	Dias_Acumulados decimal(6,2) NOT NULL,
	Dias_Tomado decimal(6,2) NOT NULL,
	Dias_Disponibles decimal(6,2) NOT NULL,
	idEmpleado_Sal_Vac INT NOT NULL,
    CONSTRAINT FK_Empleado_Sal_Vac FOREIGN KEY (idEmpleado_Sal_Vac) REFERENCES Empleado(idEmpleado) --Empleado propietario del saldo
);

select * from Vacacion_Saldo



 ---------------------------Tablas de la parte de Asistencia y Permisos---------------------------

 --Tabla: Asistencia_Estado
 /*Estado de de la asistencia del empleado:
 1.Presente
 2.Ausente
 3.Tardanza
 4.Permiso*/
CREATE TABLE Asistencia_Estado (
    idAsis_Estado INT IDENTITY(1,1) PRIMARY KEY,
    TipoEstado VARCHAR(20) NOT NULL
);
INSERT INTO Asistencia_Estado (TipoEstado) VALUES 
('Presente'),
('Ausente'),
('Tardanza'),
('Permiso');


--Tabla: Asistencia
/*Registro diario de entrada y salida de cada empleado*/
CREATE TABLE Asistencia (
    idAsistencia INT IDENTITY(1,1) PRIMARY KEY,
    Fecha date NOT NULL,
	Hora_Entrada time NOT NULL,
	Hora_Salida time NOT NULL,
	Horas_Extra time NOT NULL,
	idAsis_Estado int NOT NULL,
    CONSTRAINT FK_Asistencia_Estado FOREIGN KEY (idAsis_Estado) REFERENCES Asistencia_Estado(idAsis_Estado),
	idEmpleado int NOT NULL,
    CONSTRAINT FK_Empleado_Asis FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado) --Empleado al que corresponde el registro
);

select * from Asistencia


--Tabla: TipoPermiso
/*Tipo de permiso por ausencia*/
CREATE TABLE TipoPermiso (
    id_TipoPermiso INT IDENTITY(1,1) PRIMARY KEY,
    Tipo_Permiso VARCHAR(80) NOT NULL
);
INSERT INTO TipoPermiso (Tipo_Permiso) VALUES 
('Incapacidad médica'),
('Permiso Persona'),
('Cita médica'),
('Licencia de maternidad'),
('Licencia de paternidad'),
('Duelo'),
('Estudios'),
('Vacaciones'),
('Otro');

SELECT * FROM TipoPermiso


--Tabla: Permiso
/*Justificación o permiso asociado a un registro de asistencia. No toda asistencia tiene permiso,
por eso es una tabla aparte*/
CREATE TABLE Permiso (
    idPermiso INT IDENTITY(1,1) PRIMARY KEY,
	Activo BIT NOT NULL DEFAULT 1, --Estado 1.Activo  0.Inactivo
	Justificacion VARCHAR(5000) NOT NULL,
	id_TipoPermiso int NOT NULL,
    CONSTRAINT FK_TipoPermiso FOREIGN KEY (id_TipoPermiso) REFERENCES TipoPermiso(id_TipoPermiso), --Tipo de permisos
	idAsistencia int NOT NULL,
    CONSTRAINT FK_Asistencia FOREIGN KEY (idAsistencia) REFERENCES Asistencia(idAsistencia), --Registro de asistencia justificada
	idEmpleado int NOT NULL,
    CONSTRAINT FK_Emp_Permiso FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado) --Registro de asistencia justificada
);

select * from Permiso



---------------------------Tablas de la parte de Acciones y Rotaciones del Personal---------------------------
--Tabla: Accion_Personal
/*Registro mensual de movimientos de personal (cabecera).
Cada mes puede haber una más acciones por empleado*/
CREATE TABLE Accion_Personal (
    idAccion INT IDENTITY(1,1) PRIMARY KEY,
    Fecha date NOT NULL,
	idEmpleado int NOT NULL,
    CONSTRAINT FK_Empleado_Accion FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado) --Empleado al que se aplica la acción
);

select * from Accion_Personal


--Tabla: Detalle_Accion
/*Tipo especifico de acción dentro de un registro de
Accion_Tipo: (Ajuste Salarial, Ascenso, Traslado,
Acción Disciplinaria, Licencia, Premio, Plan de mejora,
Acción Disciplinaria, Comunicado, Otro)*/
CREATE TABLE Detalle_Accion (
    id_Detalle_Accion INT IDENTITY(1,1) PRIMARY KEY,
    Accion VARCHAR(80) NOT NULL
);
INSERT INTO Detalle_Accion (Accion) VALUES 
('Ajuste Salarial'),
('Ascenso'),
('Traslado'),
('Acción Disciplinaria'),
('Licencia'),
('Premio'),
('Plan de mejora'),
('Acción Disciplinaria'),
('Comunicado'),
('Otro');

select * from Detalle_Accion


--Tabla: Accion_Tipo
/*Detalle unificado con la cabecera y el tipo de acción*/
CREATE TABLE Accion_Tipo (
    idAccion_Tipo INT IDENTITY(1,1) PRIMARY KEY,
	Detalle VARCHAR(600) NOT NULL,
	Monto_TA DECIMAL(12,2) NULL,
	id_Detalle_Accion int NOT NULL,
    CONSTRAINT FK_Detalle_Accion FOREIGN KEY (id_Detalle_Accion) REFERENCES Detalle_Accion(id_Detalle_Accion), --Tipo de acción
	idAccion int NOT NULL,
    CONSTRAINT FK_Accion_Personal FOREIGN KEY (idAccion) REFERENCES Accion_Personal(idAccion), --La cabecera que se creo
	
	/*Se obtiene solo si el usuario selecciona la opción Ajuste Salaria
	o Ascenso, es importante que el nuevo monto que se ingrese se debe de ver
	reflejado dentro de la tabla Salario_Empleado, en el campo Salario_Sem_Neto.
	Tambien recordar que el campo Monto_TA debe de mostrar el valor ingresado.*/
	idSalarioEmpleado int NULL,
    CONSTRAINT FK_Salario_Empleado_AT FOREIGN KEY (idSalarioEmpleado) REFERENCES Salario_Empleado(idSalarioEmpleado),

	/*Se obtiene solo si el usuario selecciona la opción Premio,
	es importante que el nuevo monto que se ingrese se debe de ver
	reflejado dentro de la tabla Premio, en el campo Monto.
	Tambien recordar que el campo Monto_TA debe de mostrar el valor ingresado*/
	id_PremioAsignado INT NULL,
    CONSTRAINT FK_Premio_Asignado_AT FOREIGN KEY(id_PremioAsignado) REFERENCES Premio_Asignado(id_PremioAsignado)
);

select * from Accion_Tipo


--Tabla: Periodo
/*Periodos que se harian la evaluación
Mensual
Trimestral
Semestral
Anual*/
CREATE TABLE Periodo (
    idPeriodo INT IDENTITY(1,1) PRIMARY KEY,
	Tipo_Periodo VARCHAR(30) NOT NULL
);
-- Insertar los tipos de períodos de evaluación institucional
INSERT INTO Periodo (Tipo_Periodo) VALUES 
('Mensual'),
('Trimestral'),
('Semestral'),
('Anual');

-- Verificar la inserción de los datos
SELECT * FROM Periodo


--Tabla: Rotacion_Personal       ------ESTA TABLA ESTA PENDIENTE HASTA COMPLETAR LOS MODULOS NECESARIOS PARA TENER LA INFORMACIÓ Y HACER BIEN LOS CALCULOS
/*Historial del IRP calculado por período.
Todos los valores se obtienen automáticamente desde
las tablas: Empleado, Onboarding, Offboarding y Causa_Salida*/
CREATE TABLE Rotacion_Personal (
    idRotacion INT IDENTITY(1,1) PRIMARY KEY,
    Anio INT NOT NULL,
    Mes INT NULL,
	A_Contratados INT NOT NULL,
	D_Desvinculados INT NOT NULL, --Numero de personas Desvinculadas
	D_Jubilaciones_Defuncionales INT NOT NULL, --Numero de personas Desvinculadas (Bajas naturales)
	D_Total_Bajas INT NOT NULL, --Total de la suma entre (D_Desvinculados + D_Jubilaciones_Defuncionales)
	F1_Inicio INT NOT NULL, --Numero de trabajadores al inicio del periodo
	F2_Final INT NOT NULL, --Numero de trabajadores al final del periodo

	IRP DECIMAL(5,2) NOT NULL, --Calculado automatico por formula
	IRP_Sugerido_Min DECIMAL(5,2) NOT NULL, --Calculado automatico
    IRP_Sugerido_Max DECIMAL(5,2) NOT NULL, --Calculado automatico
);

select * from Rotacion_Personal



---------------------------Tablas de la parte de Evaluación de Desempeño---------------------------
--Tabla: Evaluacion
/*Cabecera de cada evaluación de desempeño realizada a un empleado*/
CREATE TABLE Evaluacion (
    idEvaluacion INT IDENTITY(1,1) PRIMARY KEY,
    Fecha_Evaluacion date NOT NULL,
	idPeriodo int NOT NULL,
    CONSTRAINT FK_Periodo_EV FOREIGN KEY (idPeriodo) REFERENCES Periodo(idPeriodo), --Tipo de periodo de evaluación
	idEmpleado_Ev int NOT NULL,
    CONSTRAINT FK_Empleado_Ev FOREIGN KEY (idEmpleado_Ev) REFERENCES Empleado(idEmpleado), --Empleado evaluado (puede ser corriente o de jefatura)
	idEmpleado_Jef int NOT NULL,
    CONSTRAINT FK_Empleado_Jef FOREIGN KEY (idEmpleado_Jef) REFERENCES Empleado(idEmpleado) --Empleado de jefatura que hace la evaluacion
);

select * from Evaluacion


--Tabla: Evaluacion_Desempeno
/*Cada criterio individual evaluado dentro de una evaluación
Se utiliza una calificación de 0 y 1.
Y todo es de manera porcentual, por lo que se van contando los puntos
y de ahi se saca el porcentaje total de la evaluación.
Esto debe de quedar guardado en los reportes/resumenes para la empresa.
*/
CREATE TABLE Evaluacion_Desempeno (
    id_Desempeno INT IDENTITY(1,1) PRIMARY KEY,
    Cumple_Metas_Objetivos BIT NOT NULL,
    Cumple_FuncionesAsig BIT NOT NULL,
    Entregables_Calidad_Tiempo BIT NOT NULL,
    Cumple_Asistencia BIT NOT NULL,
    Muestra_Compromiso_Colaboracion BIT NOT NULL,
	pct_totalEv decimal(12,2), --A este campo se le agrega automaticamente el resultado
	Observaciones VARCHAR(500) NOT NULL,
    idEvaluacion INT NOT NULL,
    CONSTRAINT FK_Evaluacion FOREIGN KEY (idEvaluacion) REFERENCES Evaluacion(idEvaluacion)
);

select * from Evaluacion_Desempeno


--Tabla: Evaluacion_JefePotencial
/*Evaluación del potencial del colaborador realizada por la jefatura directa
Se utiliza una calificación de 0 y 1.
Y todo es de manera porcentual, por lo que se van contando los puntos
y de ahi se saca el porcentaje total de la evaluación.
Esto debe de quedar guardado en los reportes/resumenes para la empresa.*/
CREATE TABLE Evaluacion_JefePotencial (
    id_Eva_JefePote INT IDENTITY(1,1) PRIMARY KEY,
    Capacidad_Liderazgo BIT NOT NULL,
	Aprendizaje_Rapido BIT NOT NULL,
	Adaptacion_Cambio BIT NOT NULL,
	Iniciativa_Mejora BIT NOT NULL,
	Madurez_Emocional BIT NOT NULL,
	pct_totalEv decimal(12,2), --A este campo se le agrega automaticamente el resultado
	Observaciones VARCHAR(500) NOT NULL,
	idEvaluacion int NOT NULL,
    CONSTRAINT FK_Evaluacion_Jef FOREIGN KEY (idEvaluacion) REFERENCES Evaluacion(idEvaluacion) --Evaluación general a la que pertenece
);

select * from Evaluacion_JefePotencial


--Tablas: Cuadrante_9box_Perfil
/*Tabla del perfil del cuadrante para la matriz*/
CREATE TABLE Cuadrante_9box_Perfil (
    idCuadrante_9box_Perfil INT IDENTITY(1,1) PRIMARY KEY,
	Tipo_Profecional VARCHAR(80) NOT NULL,
	Perfil VARCHAR(500)  NOT NULL,
);
INSERT INTO Cuadrante_9box_Perfil (Tipo_Profecional, Perfil) VALUES
('Talento Estrella (High-Po / High-Perf)', 
 'Colaborador con alto desempeño y alto potencial. Son los futuros líderes ejecutivos de la organización; crecen rápido, asumen retos complejos con facilidad y son críticos para la sucesión.'),

('Alto Potencial / Futuro Líder', 
 'Demuestra un desempeño bueno y constante, sumado a un potencial altísimo para liderar grandes proyectos, dominar nuevas competencias o ascender a jefaturas a corto plazo.'),

('Enigma / Potencial No Pulido', 
 'Presenta un desempeño bajo actualmente (por falta de experiencia, adaptación o motivación), pero posee destellos de un potencial de aprendizaje, análisis y liderazgo enorme.'),

('Profesional Clave / Especialista', 
 'Colaborador con un desempeño excepcional y dominio absoluto de su puesto actual, pero con un potencial de crecimiento vertical bajo o limitado por preferencia personal o técnica.'),

('Empleado Sólido / Núcleo', 
 'Muestra un desempeño bueno (estable) y potencial medio. Es el motor balanceado de la empresa que mantiene la operación marchando día a día con consistencia y buen ritmo.'),

('Dilema / Necesita Desarrollo', 
 'Registra un desempeño bajo pero un potencial medio. Muestra capacidades para dar más, pero existen barreras en su entorno, herramientas o capacitación que frenan su éxito.'),

('Trabajador Efectivo / Sólido Limitado', 
 'Tiene un desempeño aceptable y cumple en su zona de confort, combinado con un potencial bajo de crecimiento vertical. Requiere estímulos para no caer en la monotonía.'),

('Materia de Revisión / Alerta', 
 'Colaborador con desempeño bajo y potencial bajo. No alcanza los objetivos mínimos de su puesto ni muestra capacidad, interés o competencias para mejorar a corto plazo.'),

('Alto Profesional / Crecimiento Horizontal', 
 'Desempeño sobresaliente y potencial medio. Un experto técnico en su área que puede asumir mayores responsabilidades analíticas o especializadas, pero no de manejo de personal.')
 ;

 select * from Cuadrante_9box_Perfil


--Tabla: Cuadrante_9box (tabla inecesaria, se puede eliminar más adelante)
/*Catalogo de los nueve cuadrantes de la matriz de talentos*/
CREATE TABLE Cuadrante_9box (
    idCuadrante_9box INT IDENTITY(1,1) PRIMARY KEY,
    Cuadrante VARCHAR(5) NOT NULL
);
-- Insertar las 9 coordenadas de la matriz 9-Box
INSERT INTO Cuadrante_9box (Cuadrante) VALUES 
('B1'), -- Potencial Bajo, Desempeño Bajo (Talento de Riesgo)
('B2'), -- Potencial Bajo, Desempeño Medio
('B3'), -- Potencial Bajo, Desempeño Alto (Especialista Eficaz)
('M1'), -- Potencial Medio, Desempeño Bajo
('M2'), -- Potencial Medio, Desempeño Medio (Core Profesional)
('M3'), -- Potencial Medio, Desempeño Alto (Alta Productividad)
('A1'), -- Potencial Alto, Desempeño Bajo (Enigma / Futuro Enigma)
('A2'), -- Potencial Alto, Desempeño Medio (Estrella Creciente)
('A3'); -- Potencial Alto, Desempeño Alto (Súper Estrella / Top Talent)

-- Verificar registros
SELECT * FROM Cuadrante_9box


--Tabla: Cuadrante_9box_Desempeno
/*Nivel de desempeño del empleado*/
CREATE TABLE Cuadrante_9box_Desempeno (
    idCuadrante_9box_Desempeno INT IDENTITY(1,1) PRIMARY KEY,
    Nivel_Desempeno int NOT NULL
);
-- Insertar los 3 niveles estándar para evaluar el Desempeño laboral
INSERT INTO Cuadrante_9box_Desempeno (Nivel_Desempeno) VALUES 
('1'), -- Generará el ID de Bajo Desempeño
('2'), -- Generará el ID de Medio Desempeño
('3'); -- Generará el ID de Alto Desempeño

-- Verificar que se hayan guardado correctamente
SELECT * FROM Cuadrante_9box_Desempeno


--Tabla: Cuadrante_9box_Potencial
/*Nivel del potencial del empleado*/
CREATE TABLE Cuadrante_9box_Potencial (
    idCuadrante_9box_Potencial INT IDENTITY(1,1) PRIMARY KEY,
	Nivel_Potencial char(1) NOT NULL
);
-- Insertar los 3 niveles de Potencial utilizando un solo carácter (Letras)
INSERT INTO Cuadrante_9box_Potencial (Nivel_Potencial) VALUES 
('B'), -- Bajo Potencial
('M'), -- Medio Potencial
('A'); -- Alto Potencial

select * from Cuadrante_9box_Potencial


--Tabla: Union_Matriz_Emp
/*Tabla que se encarga de unir todas la opciones de la matriz
en una sola para asignarselo al empleado que se esta evaluando*/
CREATE TABLE Union_Matriz_Emp (
    id_Matriz INT IDENTITY(1,1) PRIMARY KEY,
	Anio int NOT NULL,
	Plan_Accion TEXT  NOT NULL,
	idPeriodo int NOT NULL,
    CONSTRAINT FK_Periodo_Matriz FOREIGN KEY (idPeriodo) REFERENCES Periodo(idPeriodo), --Evaluación general a la que pertenece
	idCuadrante_9box_Perfil int NOT NULL,
    CONSTRAINT FK_Cuadrante_9box_Perfil FOREIGN KEY (idCuadrante_9box_Perfil) REFERENCES Cuadrante_9box_Perfil(idCuadrante_9box_Perfil),
	idCuadrante_9box int NOT NULL,
    CONSTRAINT FK_Cuadrante_9box FOREIGN KEY (idCuadrante_9box) REFERENCES Cuadrante_9box(idCuadrante_9box),
	idCuadrante_9box_Desempeno int NOT NULL,
    CONSTRAINT FK_9box_Desempeno FOREIGN KEY (idCuadrante_9box_Desempeno) REFERENCES Cuadrante_9box_Desempeno(idCuadrante_9box_Desempeno),
	idCuadrante_9box_Potencial int NOT NULL,
    CONSTRAINT FK_9box_Potencial FOREIGN KEY (idCuadrante_9box_Potencial) REFERENCES Cuadrante_9box_Potencial(idCuadrante_9box_Potencial),
	idEmpleado int NOT NULL,
    CONSTRAINT FK_Empleado_Matriz FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado)
);

select * from Union_Matriz_Emp


CREATE TABLE Evaluacion_Resultado (
    -- Llave primaria autoincrementable
    idResultado INT IDENTITY(1,1) NOT NULL,
    
    -- Llaves foráneas y datos de control
    idEvaluacion INT NOT NULL,
    idEmpleado INT NOT NULL,
    Periodo INT NOT NULL, -- Año evaluado (Ej: 2026)
    
    -- Métricas y números duros
    pct_desempeno DECIMAL(5,2) NULL,
    pct_potencial DECIMAL(5,2) NULL,
    pct_semestral DECIMAL(5,2) NULL,
    pct_cliente_interno DECIMAL(5,2) NULL,
    
    -- Llave foránea para la matriz 9 Box
    id_Matriz INT NOT NULL,
    
    -- Comentario de retroalimentación
    Comentario_Cierre VARCHAR(1000) NULL,
    
    -- Definición de restricciones (Constraints)
    CONSTRAINT PK_Evaluacion_Resultado PRIMARY KEY CLUSTERED (idResultado),
    
    CONSTRAINT FK_EvaluacionResultado_Evaluacion 
        FOREIGN KEY (idEvaluacion) REFERENCES Evaluacion(idEvaluacion),
        
    CONSTRAINT FK_EvaluacionResultado_Empleado 
        FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado),
        
    CONSTRAINT FK_EvaluacionResultado_Matriz 
        FOREIGN KEY (id_Matriz) REFERENCES Union_Matriz_Emp(id_Matriz)
);

select * from Evaluacion_Resultado --NO GUARDA NADA MODIFICAR DESPUES EL HTML Y LA VISTA (EN LA WEB SI SE VE)



---------------------------Tablas de la parte de KPIs y Premios---------------------------
--Tabla: KPI_Cabecera
/*Registro mensual de KPIs por empleado y casa comercial*/
CREATE TABLE KPI_Cabecera (
    id_KPI INT IDENTITY(1,1) PRIMARY KEY,
    Mes int NOT NULL,
	Anio int NOT NULL,
	idEmpleado int NOT NULL,
    CONSTRAINT FK_Empleado_KPI FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado), --Empleado al que se le registrara el KPI
	-- Esto evita que un empleado tenga dos cabeceras el mismo mes/año:
    CONSTRAINT UQ_Empleado_Mes_Anio UNIQUE (idEmpleado, Mes, Anio)
);

select * from KPI_Cabecera


--Tabla: KPI_Categoria
/*Categorias del registro de KPI mensual*/
CREATE TABLE KPI_Categoria (
    id_KPI_Categoria INT IDENTITY(1,1) PRIMARY KEY,
    TipoCategoria VARCHAR(150) NOT NULL,
	Descripcion VARCHAR(500) NOT NULL
);
INSERT INTO KPI_Categoria (TipoCategoria, Descripcion)
VALUES 
('Financiero', 'Indicadores relacionados con el rendimiento económico, rentabilidad, ingresos, costos y flujo de caja.'),
('Clientes y Mercado', 'Evaluación de la satisfacción, retención, adquisición de clientes y participación en el mercado.'),
('Procesos Internos', 'Medición de la eficiencia operativa, calidad del producto/servicio, tiempos de ciclo y productividad.'),
('Aprendizaje y Crecimiento', 'Enfocado en la capacitación del talento humano, innovación, cultura organizacional y adopción tecnológica.'),
('Ventas y Comercial', 'Seguimiento de cumplimiento de cuotas, embudos de conversión, efectividad de campañas y nuevos contratos.'),
('Recursos Humanos', 'Indicadores de rotación de personal, clima laboral, ausentismo y desempeño de los colaboradores.'),
('Logística y Cadena de Suministro', 'Medición de tiempos de entrega, gestión de inventarios, costos de transporte y cumplimiento de proveedores.'),
('Tecnología y Sistemas', 'Monitoreo de disponibilidad de plataformas, ciberseguridad, tiempo de resolución de incidencias y soporte IT.'),
('Calidad y Cumplimiento', 'Evaluación de normativas, auditorías, tasas de defectos y cumplimiento de estándares regulatorios (ej. ISO).'),
('Sostenibilidad y ESG', 'Indicadores de impacto ambiental, responsabilidad social y gobierno corporativo.'
);

select * from KPI_Categoria


--Tabla: KPI_Detalle
/*Detalle de cada indicador dentro de un registro de KPI mensual*/
CREATE TABLE KPI_Detalle (
    id_KPI_Detalle INT IDENTITY(1,1) PRIMARY KEY,
	pct_Alcanzado decimal(5,2) NOT NULL,
	Monto_Base decimal(12,2) NOT NULL, --Valor del componenete/tipo de categoria
	Monto_Total decimal(12,2) NOT NULL, --Calculo automatico, Monto_Base * (pct_Alcanzado / 100)
	id_KPI_Categoria int NOT NULL,
	CONSTRAINT FK_KPI_Categoria FOREIGN KEY (id_KPI_Categoria) REFERENCES KPI_Categoria(id_KPI_Categoria),
	id_KPI int NOT NULL,
    CONSTRAINT FK_KPI_Cabecera_Detalle FOREIGN KEY (id_KPI) REFERENCES KPI_Cabecera(id_KPI),

	-- Evita que repitas la misma categoría de KPI en el mismo mes del empleado
    CONSTRAINT UQ_KPI_Categoria_Por_Mes UNIQUE (id_KPI, id_KPI_Categoria)
);

select * from KPI_Detalle


--Tabla: Premio
/*Catalogo de premios e incentivos que puedan asignar según resultados de KPI*/
CREATE TABLE Premio (
    idPremio INT IDENTITY(1,1) PRIMARY KEY,
    Descripcion VARCHAR(200) NOT NULL, -- Ej: 'Premio al Vendedor del Mes' o 'Incentivo a Futuros Líderes
	Alcance VARCHAR(200) NOT NULL,
	Monto decimal(12,2) NOT NULL, -- Valor monetario del premio (Ej: 50000.00)
	id_KPI_Categoria int NOT NULL,
	CONSTRAINT FK_KPI_Categoria_Premio FOREIGN KEY (id_KPI_Categoria) REFERENCES KPI_Categoria(id_KPI_Categoria),
	idCuadrante_9box_Perfil int NOT NULL,
    CONSTRAINT FK_Cuadrante_9box_Perfil_Premio FOREIGN KEY (idCuadrante_9box_Perfil) REFERENCES Cuadrante_9box_Perfil(idCuadrante_9box_Perfil)
);

select * from Premio


--Tabla: Premio_Asignado
/*Relación entre un KPI y los premios ganados*/
CREATE TABLE Premio_Asignado (
    id_PremioAsignado INT IDENTITY(1,1) PRIMARY KEY,
    Monto_Liquidado decimal(12,2) NOT NULL,
	Fecha_Registro date NOT NULL,
	idPremio int NOT NULL,
    CONSTRAINT FK_Premio FOREIGN KEY (idPremio) REFERENCES Premio(idPremio),
	id_KPI int NOT NULL,
    CONSTRAINT FK_KPI_CategPremio FOREIGN KEY (id_KPI) REFERENCES KPI_Cabecera(id_KPI) --Con este se debe traer el detalle de la cabecera y el empleado al que se le asigno el KPI_Cabecera
);

select * from Premio_Asignado


 ---------------------------Tablas de la parte de Onboarding--------------------------
--Tabla: Onboarding
/*Cabecera del proceso de ingreso de nuevo empleado*/
CREATE TABLE Onboarding (
    id_Onboarding INT IDENTITY(1,1) PRIMARY KEY,
    Fecha_Inicio date NOT NULL,
	id_Depertamento int NOT NULL,
    CONSTRAINT FK_Depa_On FOREIGN KEY (id_Depertamento) REFERENCES Departamento(id_Depertamento), --Departamento al que pertenece el empleado
	idEmpleado int NOT NULL,
    CONSTRAINT FK_Empleado_On FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado) --Empleado que entro 
);

select * from Onboarding

DELETE FROM Onboarding 
WHERE id_Onboarding IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11);



--Tabla: On_Actividad
/*Cada actividad o tarea dentro del proceso de onboarding de un empleado*/
CREATE TABLE On_Actividad (
    idActividad INT IDENTITY(1,1) PRIMARY KEY,
	Actividad VARCHAR(300) NOT NULL
);
INSERT INTO On_Actividad (Actividad)
VALUES
('Recepción y bienvenida al colaborador'),
('Entrega y firma del contrato de trabajo'),
('Entrega del reglamento interno'),
('Entrega del manual del colaborador'),
('Presentación con el equipo de trabajo'),
('Presentación con el jefe inmediato'),
('Asignación del puesto de trabajo'),
('Entrega de equipo de cómputo'),
('Entrega de credenciales de acceso'),
('Creación de correo institucional'),
('Creación de usuario en los sistemas corporativos'),
('Asignación de permisos en los sistemas'),
('Entrega de uniforme'),
('Entrega de gafete institucional'),
('Capacitación sobre políticas de la empresa'),
('Capacitación en seguridad ocupacional'),
('Capacitación sobre prevención de riesgos'),
('Capacitación en protección de datos y confidencialidad'),
('Capacitación específica del puesto'),
('Recorrido por las instalaciones'),
('Presentación de beneficios corporativos'),
('Afiliación a beneficios internos'),
('Registro de cuenta bancaria para planilla'),
('Registro de información de contacto de emergencia'),
('Entrega del plan de trabajo inicial'),
('Asignación de mentor o compañero guía'),
('Primera reunión de seguimiento'),
('Evaluación del proceso de inducción'),
('Confirmación de cumplimiento del onboarding'),
('Cierre del proceso de onboarding');

select * from On_Actividad


--Tabla: Onboarding_Actividad
/*Detalle del onboarding de un empleado*/
CREATE TABLE Onboarding_Actividad (
    id_Detalle_On INT IDENTITY(1,1) PRIMARY KEY,
	Fecha_Programada date NOT NULL,
	Fecha_Realizada date NOT NULL,
	Observaciones VARCHAR(600) NOT NULL,
	id_Estatus_Vacante int NOT NULL,
    CONSTRAINT FK_Estatus_On FOREIGN KEY (id_Estatus_Vacante) REFERENCES Estatus(id_Estatus_Vacante), --Estado en el que se encuentra el Onbording
	idActividad int NOT NULL,
    CONSTRAINT FK_Actividad_On FOREIGN KEY (idActividad) REFERENCES On_Actividad(idActividad), --FK al tipo de Actividad dentro del Onboarding seleccionada
	id_Onboarding int NOT NULL,
    CONSTRAINT FK_Onboarding FOREIGN KEY (id_Onboarding) REFERENCES Onboarding(id_Onboarding) --Proceso al que pertenece
);

select * from Onboarding_Actividad

DELETE FROM Onboarding_Actividad 
WHERE id_Detalle_On IN (1, 2, 3, 4, 5, 6);



---------------------------Tablas de la parte de Offboarding y Rotación--------------------------
--Tabla: Causa_Salida
/*Catálogo de causas de salida de la empresa*/
CREATE TABLE Causa_Salida (
    idCausa INT IDENTITY(1,1) PRIMARY KEY,
    Causa VARCHAR(150) NOT NULL,
	Categoria VARCHAR(80) NOT NULL
);
INSERT INTO Causa_Salida (Causa, Categoria) VALUES
-- Categoría: Voluntaria (El empleado decide irse)
('Mejor oferta económica', 'Voluntaria'),
('Crecimiento profesional / Nueva oportunidad', 'Voluntaria'),
('Cambio de residencia / Relocalización', 'Voluntaria'),
('Motivos personales / Familiares', 'Voluntaria'),
('Estudios / Continuar preparación', 'Voluntaria'),
('Clima laboral / Relación con el equipo', 'Voluntaria'),

-- Categoría: Involuntaria (La empresa decide la salida)
('Rescisión de contrato por rendimiento', 'Involuntaria'),
('Faltas graves al código de ética / Conducta', 'Involuntaria'),
('Recorte de personal / Reestructuración', 'Involuntaria'),
('Fin de proyecto o contrato temporal', 'Involuntaria'),
('Inasistencias injustificadas (Abandono de empleo)', 'Involuntaria'),

-- Categoría: Retiro / Fuerza Mayor
('Jubilación / Pensión', 'Retiro'),
('Invalidez permanente', 'Retiro'),
('Fallecimiento', 'Fuerza Mayor');

select * from Causa_Salida


--Tabla: Offboarding
/*Proceso de salida de un empleado*/
CREATE TABLE Offboarding (
    id_Offboarding INT IDENTITY(1,1) PRIMARY KEY,
    Fecha_Salida date NOT NULL,
	Descrip_Causa TEXT NOT NULL,
	idEmpleado int NOT NULL,
    CONSTRAINT FK_Empleado_OFF FOREIGN KEY (idEmpleado) REFERENCES Empleado(idEmpleado), --Empleado que sale
	idCausa int NOT NULL,
    CONSTRAINT FK_Causa_Salida FOREIGN KEY (idCausa) REFERENCES Causa_Salida(idCausa) --Causa de salida
);

select * from Offboarding

delete from Offboarding
where id_Offboarding = 4


--Tabla: Offboarding_Catalogo
/*Catalogo fijo de actividades predefinidas del proceso de offboarding.
Se carga una sola vez al instalar el sistema*/
CREATE TABLE Offboarding_Catalogo (
    idCatalogo INT IDENTITY(1,1) PRIMARY KEY,
	Num_Etapa TINYINT NOT NULL,
	Etapa VARCHAR(80) NOT NULL,
	Actividad VARCHAR(300) NOT NULL
);
INSERT INTO Offboarding_Catalogo (Num_Etapa, Etapa, Actividad) VALUES
-- ETAPA 1: Gestión Administrativa
(1, 'Administrativa', 'Recibir carta de renuncia firmada'),
(1, 'Administrativa', 'Validar fecha oficial de salida'),
(1, 'Administrativa', 'Realizar cálculo de liquidación'),

-- ETAPA 2: Activos de la empresa
(2, 'Activos', 'Solicitar devolución de equipo asignado'),
(2, 'Activos', 'Validar entrega de computadora portátil'),
(2, 'Activos', 'Validar entrega de teléfono corporativo'),

-- ETAPA 3: Sistemas
(3, 'Sistemas', 'Desactivar usuario de correo corporativo'),
(3, 'Sistemas', 'Eliminar accesos a sistemas internos'),
(3, 'Sistemas', 'Retirar permisos de aplicaciones'),

-- ETAPA 4: Recursos Humanos
(4, 'Recursos Humanos', 'Realizar entrevista de salida'),
(4, 'Recursos Humanos', 'Actualizar expediente del colaborador'),
(4, 'Recursos Humanos', 'Archivar documentación laboral'),

-- ETAPA 5: Cierre
(5, 'Cierre', 'Confirmar finalización del proceso de salida');

select * from Offboarding_Catalogo


--Tabla: Offboarding_Checklist
/*Registro de cada actividad en un proceso de offboarding específico*/
CREATE TABLE Offboarding_Checklist(
	id_Check INT IDENTITY(1,1) PRIMARY KEY,
	Fecha_Asignacion DATE NOT NULL DEFAULT(GETDATE()),
	Fecha_Comp DATE NULL,
	Observacion VARCHAR(500) NULL,
	pct_listo DECIMAL(5,2) NOT NULL DEFAULT 0,

	id_Offboarding INT NOT NULL,
	CONSTRAINT FK_Check_Offboarding FOREIGN KEY(id_Offboarding) REFERENCES Offboarding(id_Offboarding),
    id_Estatus_Vacante INT NOT NULL,
    CONSTRAINT FK_Check_Estatus FOREIGN KEY(id_Estatus_Vacante) REFERENCES Estatus(id_Estatus_Vacante),

    CONSTRAINT UQ_Check_Offboarding UNIQUE(id_Offboarding)
);

select * from Offboarding_Checklist

delete from Offboarding_Checklist
where id_Check = 5



CREATE TABLE Offboarding_Checklist_Detalle( ----------------NUEVA TABLA
    idDetalle INT IDENTITY(1,1) PRIMARY KEY,
	Fecha_Actualizacion DATETIME DEFAULT(GETDATE()),
	Completado BIT NOT NULL DEFAULT 0,

    id_Check INT NOT NULL,
	CONSTRAINT FK_Detalle_Check FOREIGN KEY(id_Check) REFERENCES Offboarding_Checklist(id_Check) ON DELETE CASCADE,
    idCatalogo INT NOT NULL,
	CONSTRAINT FK_Detalle_Catalogo FOREIGN KEY(idCatalogo) REFERENCES Offboarding_Catalogo(idCatalogo),

    CONSTRAINT UQ_Check_Catalogo UNIQUE(id_Check,idCatalogo)
);

select * from Offboarding_Checklist_Detalle

DELETE FROM Offboarding_Checklist_Detalle 
WHERE idDetalle IN (49, 50);



---------------------------Tablas de la parte de Roles en los Usuarios--------------------------

--Tabla: Roles
--Tabla para los roles que se le asignaran a los usuarios que utilizaran el sistema
CREATE TABLE Roles (
    idRol INT IDENTITY(1,1) PRIMARY KEY,
    TipoRol VARCHAR(50) NOT NULL
);

INSERT INTO Roles (TipoRol) VALUES 
/*Acceso total al sistema. Puede crear, modificar y eliminar cualquier registro,
administrar usuarios, roles y permisos, configurar el sistema, ver todos los reportes
y realizar respaldos o configuraciones generales.*/
('Administrador Global'),

/*Administra toda la información de Recursos Humanos: empleados, reclutamiento,
onboarding, offboarding, vacaciones, salarios, acciones de personal, evaluaciones, KPIs,
premios, capacitaciones y reportes.
No puede administrar usuarios ni modificar la configuración del sistema.*/
('Gestor de Talento Humano'),

/*Acceso únicamente a la información de su departamento. Puede consultar colaboradores a su cargo,
ver vacaciones, evaluar desempeño, revisar KPIs, iniciar solicitudes de acciones de personal
y consultar reportes relacionados con su equipo. No puede modificar datos globales
ni información de otros departamentos.*/
('Jefatura / Supervisor'),

/*Administra aspectos técnicos del sistema: creación y desbloqueo de usuarios,
restablecimiento de contraseñas, mantenimiento, respaldo y monitoreo del sistema.
Puede acceder a configuraciones técnicas, pero no debe modificar información de RRHH como salarios,
evaluaciones o expedientes.*/
('Soporte Técnico TI'),

/*Puede consultar toda la información del sistema y generar reportes,
pero no puede crear, editar ni eliminar registros. Ideal para auditorías internas o externas.*/
('Auditor / Solo Lectura');

select * from Roles

--Tabla: UsuarioSistema
--Tabla para los usuarios con permisos dentro del sistema
CREATE TABLE UsuarioSistema (
    id_Admin INT IDENTITY(1,1) PRIMARY KEY,
    Correo VARCHAR(200) NOT NULL,
	Contrasenia VARCHAR(128) NOT NULL,
	idRol INT NOT NULL,
	CONSTRAINT FK_Roles FOREIGN KEY (idRol) REFERENCES Roles(idRol),
	Activo BIT NOT NULL DEFAULT 1, -- 1 = Activo, 0 = Inactivo, Es el estado del usuario
	idEmpleado_Admin INT NOT NULL,
    CONSTRAINT FK_Empleado_Admin FOREIGN KEY (idEmpleado_Admin) REFERENCES Empleado(idEmpleado)
);

select * from UsuarioSistema

